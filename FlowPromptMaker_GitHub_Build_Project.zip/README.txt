Flow Prompt Maker Android Project
================================
This is an Android Studio project source, not a precompiled APK.

Features:
- Generates Image Prompt and Video Prompt text for 3, 5, 8 or 10 scenes
- 5/8/10-second scene options
- Chinese historical, romance, comedy, wuxia, fantasy, and custom story modes
- Burmese, Mandarin, or no-dialogue audio option
- Copy buttons for each prompt

How to build APK:
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync and install any requested Android SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk

Note: This starter app creates prompt text locally. It does not connect to Google Flow or generate videos itself.
